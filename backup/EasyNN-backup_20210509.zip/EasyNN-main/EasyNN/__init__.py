from EasyNN.examples.mnist import mnist
