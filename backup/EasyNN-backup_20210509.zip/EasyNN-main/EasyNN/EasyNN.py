from examples.mnist import mnist as mnist

class NeuralNetwork:
    """General NN structure which allows greater flexibility (and
     neuroevolution?)."""


    def train(self):
        """ Train is used to take a data set and train it based on an input
        and output."""
        print("Hello NN World!")
