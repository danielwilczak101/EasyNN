from EasyNN.model.Model import Model


class Activation(Model):
    """Generic activation model API."""
    pass
